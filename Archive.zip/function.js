/* block of code which can be used multiple times - creates a reusibility factor 
    for an atomic logic 
*/
function isEven(n){
    if(n % 2 === 0){
        return true
    }
    return false
}

function logEverySituation(){
    //this function is made to create logs which can be reviewed later 
}

const answrer = isEven(11);
const answrer2 = isEven(12);
const answrer3 = isEven(13);
const answrer4 = isEven(14);

if(answrer || answrer2 || answrer3 || answrer4){
    //user is allowed to clear the stage -> some meaningfuls step
}